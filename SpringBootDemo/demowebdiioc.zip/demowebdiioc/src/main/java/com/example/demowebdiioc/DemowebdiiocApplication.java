package com.example.demowebdiioc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemowebdiiocApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemowebdiiocApplication.class, args);
	}

}
