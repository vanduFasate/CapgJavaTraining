package com.example.demowebdiioc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowebdiiocApplicationTests {

	@Test
	void contextLoads() {
	}

}
