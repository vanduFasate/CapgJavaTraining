package com.example.demomoviesportssession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomoviesportssessionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomoviesportssessionApplication.class, args);
	}

}
