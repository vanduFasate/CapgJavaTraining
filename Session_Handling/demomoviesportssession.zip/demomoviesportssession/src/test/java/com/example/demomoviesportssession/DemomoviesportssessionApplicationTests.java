package com.example.demomoviesportssession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomoviesportssessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
