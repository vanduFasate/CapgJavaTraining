package com.example.otouserdefined;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtouserdefinedApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtouserdefinedApplication.class, args);
	}

}
