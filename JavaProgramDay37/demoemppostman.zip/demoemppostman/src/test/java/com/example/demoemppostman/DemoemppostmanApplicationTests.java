package com.example.demoemppostman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoemppostmanApplicationTests {

	@Test
	void contextLoads() {
	}

}
