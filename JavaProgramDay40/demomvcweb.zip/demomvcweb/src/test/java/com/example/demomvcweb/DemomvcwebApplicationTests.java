package com.example.demomvcweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomvcwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
