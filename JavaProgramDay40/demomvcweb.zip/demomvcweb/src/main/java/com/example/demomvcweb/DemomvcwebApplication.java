package com.example.demomvcweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomvcwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomvcwebApplication.class, args);
	}

}
