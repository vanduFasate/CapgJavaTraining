package com.example.demouspassdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemouspassdbApplicationTests {

	@Test
	void contextLoads() {
	}

}
