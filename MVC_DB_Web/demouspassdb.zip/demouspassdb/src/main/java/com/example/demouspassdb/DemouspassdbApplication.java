package com.example.demouspassdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemouspassdbApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemouspassdbApplication.class, args);
	}

}
