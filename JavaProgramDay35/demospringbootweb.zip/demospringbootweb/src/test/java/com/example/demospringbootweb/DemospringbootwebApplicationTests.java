package com.example.demospringbootweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemospringbootwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
