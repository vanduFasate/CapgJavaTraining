package com.example.demospringbootweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemospringbootwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemospringbootwebApplication.class, args);
	}

}
