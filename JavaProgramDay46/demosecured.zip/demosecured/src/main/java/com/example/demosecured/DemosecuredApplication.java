package com.example.demosecured;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemosecuredApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemosecuredApplication.class, args);
	}

}
