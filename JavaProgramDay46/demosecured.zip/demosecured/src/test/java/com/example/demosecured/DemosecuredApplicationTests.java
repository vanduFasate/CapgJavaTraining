package com.example.demosecured;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemosecuredApplicationTests {

	@Test
	void contextLoads() {
	}

}
