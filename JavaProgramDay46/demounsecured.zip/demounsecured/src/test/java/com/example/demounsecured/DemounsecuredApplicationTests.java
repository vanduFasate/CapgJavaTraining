package com.example.demounsecured;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemounsecuredApplicationTests {

	@Test
	void contextLoads() {
	}

}
