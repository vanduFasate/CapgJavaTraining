package com.example.websecuredcreateusers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsecuredcreateusersApplicationTests {

	@Test
	void contextLoads() {
	}

}
