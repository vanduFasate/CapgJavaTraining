package com.example.demomoviesports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomoviesportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
