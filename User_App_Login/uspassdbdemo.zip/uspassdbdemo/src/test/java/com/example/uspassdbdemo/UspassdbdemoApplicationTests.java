package com.example.uspassdbdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UspassdbdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
