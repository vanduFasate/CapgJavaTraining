package com.example.onetoonedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnetoonedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
