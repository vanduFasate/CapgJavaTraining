package com.example.onetoonedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnetoonedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnetoonedemoApplication.class, args);
	}

}
