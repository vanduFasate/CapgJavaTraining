package com.example.demovaliduser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemovaliduserApplicationTests {

	@Test
	void contextLoads() {
	}

}
