package com.example.demovaliduser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemovaliduserApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemovaliduserApplication.class, args);
	}

}
