package com.example.jpqldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpqldemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
